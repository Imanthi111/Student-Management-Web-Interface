import React from 'react';
import './App.css';
import Information from './Component/getDetails';
function App() {
  return (
    <div className="App">
      <Information/>
    </div>
  );
}
export default App;
